from langchain_community.document_loaders import TextLoader, PyPDFLoader
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage
from langchain_community.tools import DuckDuckGoSearchRun
from langchain_core.documents import Document
import os
from dotenv import load_dotenv

# ---------- LOAD ENV ---------- #
load_dotenv()
groq_api_key = os.getenv("GROQ_API_KEY")

if not groq_api_key:
    raise ValueError("GROQ_API_KEY not found in .env")

# ---------- INITIAL SETUP ---------- #

# Load initial data (optional)
documents = []
data_files = ["data.txt"]  # add more if needed

for file in data_files:
    if not os.path.exists(file):
        continue

    if file.endswith(".txt"):
        loader = TextLoader(file)
    elif file.endswith(".pdf"):
        loader = PyPDFLoader(file)
    else:
        continue

    documents.extend(loader.load())

# Split data
text_splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=50)

docs = text_splitter.split_documents(documents) if documents else []

# Embeddings
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# Persistent DB
db = Chroma(
    persist_directory="chroma_db",
    embedding_function=embeddings
)

# Load initial data only if DB is empty
if docs and len(db.get()["ids"]) == 0:
    db.add_documents(docs)
    db.persist()
    print("📄 Initial data loaded into DB")

# Web search
search = DuckDuckGoSearchRun()

# LLM
chat_model = ChatGroq(
    model="llama-3.1-8b-instant",
    temperature=0.5,
    max_tokens=512,
    api_key=groq_api_key,
)

# ---------- ADD DOCUMENT FUNCTION (FIXED) ---------- #
def add_documents_to_db(new_documents):
    global db, text_splitter

    split_docs = text_splitter.split_documents(new_documents)

    db.add_documents(split_docs)
    db.persist()

    print("📄 New documents added to DB")


# ---------- MAIN FUNCTION ---------- #
def get_response(query: str) -> dict:
    # Step 1: similarity check
    results_with_score = db.similarity_search_with_score(query, k=1)

    use_web = False
    source = "local"
    context = ""

    if not results_with_score:
        use_web = True
    else:
        _, score = results_with_score[0]
        print("🔎 Similarity score:", score)

        if score is None or score > 0.6:
            use_web = True

    # Step 2: get context
    if use_web:
        print("🌐 Using web search")
        web_result = search.run(query)
        context = f"Web Result:\n{web_result}"
        source = "web"
    else:
        print("📄 Using local DB")
        results = db.similarity_search(query, k=3)
        context = "\n\n".join([doc.page_content for doc in results])

    # Step 3: prompt
    prompt = f"""
You are a helpful AI assistant.

Use the provided context to answer the question.
If the context is from web, you may expand slightly.
If from local DB, prioritize it strictly.

Context:
{context}

Question:
{query}

Answer:
"""

    # Step 4: generate
    response = chat_model.invoke([HumanMessage(content=prompt)])
    answer = response.content

    # Step 5: store useful web answers
    if source == "web" and len(answer) > 50:
        try:
            should_store = True

            if results_with_score:
                _, score = results_with_score[0]
                if score is not None and score < 0.3:
                    should_store = False

            if should_store:
                doc = Document(
                    page_content=answer,
                    metadata={"source": "web_llm", "question": query}
                )
                db.add_documents([doc])
                db.persist()
                print("💾 Stored new knowledge")
            else:
                print("⚠️ Skipped storing (duplicate)")

        except Exception as e:
            print("Storage error:", e)

    return {
        "answer": answer,
        "source": source
    }